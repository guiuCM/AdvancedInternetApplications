// App.jsx
import React, { useState, useEffect } from 'react';
import './App.css';
import localItems from './items.json';

const App = () => {
  const [items, setItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [newItem, setNewItem] = useState({ name: '', description: '', image: '', rating: 1 });

  useEffect(() => {
    setItems(localItems);
  }, []);

  const handleDelete = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  const handleAdd = () => {
    if (!newItem.name || !newItem.description || !newItem.image) return;
  
    const newItemWithId = {
      ...newItem,
      id: Date.now(), // ID único usando timestamp
    };
  
    setItems([...items, newItemWithId]);
    setNewItem({ name: '', description: '', image: '', rating: 1 });
  };

  const handleRatingChange = (id, newRating) => {
    const updated = items.map(item =>
      item.id === id ? { ...item, rating: newRating } : item
    );
    setItems(updated);
  };

  const sortedItems = [...items]
    .filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0;
    });

  return (
    <div className="app-container">
      <h1>My pet Shelter</h1>

      <div className="controls">
        <input
          type="text"
          placeholder="Search..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
          <option value="name">Sort by Name</option>
          <option value="rating">Sort by Rating</option>
        </select>
      </div>

      <div className="items-grid">
        {sortedItems.map((item) => (
          <div className="item-card" key={item.id}>
            <img src={item.image} alt={item.name} className="item-image" />
            <h2>{item.name}</h2>
            <p>{item.description}</p>
            <div className="rating">
              <span>Rating:</span>
              <select
                value={item.rating}
                onChange={(e) => handleRatingChange(item.id, parseInt(e.target.value))}
              >
                {[1, 2, 3, 4, 5].map(num => (
                  <option key={num} value={num}>{num}</option>
                ))}
              </select>
            </div>
            <button onClick={() => handleDelete(item.id)} className="delete-button">Delete</button>
          </div>
        ))}
      </div>

      <div className="add-form">
        <h2>Add New Item</h2>
        <input
          placeholder="Name"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
        />
        <input
          placeholder="Description"
          value={newItem.description}
          onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
        />
        <input
          placeholder="Image URL"
          value={newItem.image}
          onChange={(e) => setNewItem({ ...newItem, image: e.target.value })}
        />
        <input
          type="number"
          min="1"
          max="5"
          placeholder="Rating (1-5)"
          value={newItem.rating}
          onChange={(e) => setNewItem({ ...newItem, rating: parseInt(e.target.value) })}
        />
        <button onClick={handleAdd}>Add Item</button>
      </div>
    </div>
  );
};

export default App;
